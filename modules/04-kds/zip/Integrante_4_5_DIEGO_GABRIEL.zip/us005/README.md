# US-005 — Expedição e Controle de Balcão / Salão

## O que foi implementado
- Painel de pedidos prontos para expedição.
- Filtros por Todos, Balcão e Salão.
- Busca por número, nome ou mesa.
- Chamada de pedidos de balcão.
- Painel público de chamadas.
- Aviso ao garçom para pedidos do salão.
- Controle de mesas com pedido pronto.
- Marcação de pedido como entregue.
- Indicador de tempo de espera e destaque para pedidos mais antigos.
- Persistência local via `localStorage` para demonstração.

## Integração com a US-004 (KDS)
A entrada esperada é um pedido com `status = "ready"`.

Formato sugerido:

```js
{
  id: 125,
  mode: "Balcão", // ou "Mesa 03" / "Mesa 05"
  status: "ready",
  created: "20:11",
  mins: 3,
  customer: "João",
  items: [["1x", "Calabresa", "Média"]]
}
```

Na integração real, substitua `DEMO_ORDERS` em `js/expedicao.js` por uma chamada à API/banco compartilhado com a US-004.

## Como abrir
Abra `us005/expedicao.html` no navegador.
