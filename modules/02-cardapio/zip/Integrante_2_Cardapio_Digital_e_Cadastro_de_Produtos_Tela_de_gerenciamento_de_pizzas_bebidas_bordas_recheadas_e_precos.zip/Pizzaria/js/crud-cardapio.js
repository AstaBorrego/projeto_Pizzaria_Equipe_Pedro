// Vetor que armazena os itens do cardápio
let cardapio = [];

// Guarda o índice da pizza quando estiver editando
let indiceEdicao = -1;

// CREATE e UPDATE
function cadastrarPizza() {

    const nome = document.getElementById("nomePizza").value.trim();
    const preco = Number(document.getElementById("precoPizza").value);
    const categoria = document.getElementById("categoria").value;
    const ingredientes = document.getElementById("ingredientes").value.trim();
    const disponivel = document.getElementById("disponivel").value;

    if (nome === "" || preco <= 0 || categoria === "") {
        alert("Preencha todos os campos corretamente.");
        return;
    }

    const pizza = {
        nome,
        preco,
        categoria,
        ingredientes,
        disponivel
    };

    if (indiceEdicao === -1) {
        // CREATE
        cardapio.push(pizza);
        alert("Item cadastrado com sucesso!");
    } else {
        // UPDATE
        cardapio[indiceEdicao] = pizza;
        alert("Item atualizado com sucesso!");
        indiceEdicao = -1;
    }

    limparFormulario();
    mostrarCardapio();
}

// READ
function mostrarCardapio() {

    const tabela = document.getElementById("tabelaCardapio");
    tabela.innerHTML = "";

    cardapio.forEach((pizza, indice) => {

        tabela.innerHTML += `
            <tr>
                <td>${pizza.nome}</td>
                <td>${pizza.categoria}</td>
                <td>R$ ${pizza.preco.toFixed(2)}</td>
                <td>${pizza.ingredientes}</td>
                <td>${pizza.disponivel}</td>
                <td>
                    <button onclick="editarPizza(${indice})">Editar</button>
                    <button onclick="excluirPizza(${indice})">Excluir</button>
                </td>
            </tr>
        `;
    });
}

// UPDATE - coloca os dados no formulário
function editarPizza(indice) {

    const pizza = cardapio[indice];

    document.getElementById("nomePizza").value = pizza.nome;
    document.getElementById("precoPizza").value = pizza.preco;
    document.getElementById("categoria").value = pizza.categoria;
    document.getElementById("ingredientes").value = pizza.ingredientes;
    document.getElementById("disponivel").value = pizza.disponivel;

    indiceEdicao = indice;
}

// DELETE
function excluirPizza(indice) {

    const confirmar = confirm(
        `Deseja excluir "${cardapio[indice].nome}"?`
    );

    if (confirmar) {
        cardapio.splice(indice, 1);
        mostrarCardapio();
        alert("Item excluído.");
    }
}

// Limpa o formulário
function limparFormulario() {

    document.getElementById("nomePizza").value = "";
    document.getElementById("precoPizza").value = "";
    document.getElementById("categoria").value = "";
    document.getElementById("ingredientes").value = "";
    document.getElementById("disponivel").value = "Disponível";
}